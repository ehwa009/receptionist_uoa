# Setup
To deploy, please create a zip of this folder root directory and upload to AWS lambda

# Directions.js
Contains a map between known people at UOA and where to find them. Please update this to allow Ever receptionist
